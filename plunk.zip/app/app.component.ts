import {
    Component,
    ViewEncapsulation
} from '@angular/core';

import { tap } from 'rxjs/operators/tap';
import { switchMap } from 'rxjs/operators/switchMap';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';

import { OrdersService } from './northwind.service';

@Component({
    encapsulation: ViewEncapsulation.None,
    providers: [OrdersService],
    selector: 'my-app',
    template: `
      <kendo-grid
          [data]="query | async"
          [loading]="loading"
          [skip]="state.skip"
          [pageSize]="state.take"
          [scrollable]="'virtual'"
          [rowHeight]="40"
          [height]="450"
          (pageChange)="pageChange($event)"
        >
        <kendo-grid-column field="OrderID" [width]="80" title="ID"></kendo-grid-column>
        <kendo-grid-column field="ShipName" title="Ship Name" [width]="200"></kendo-grid-column>
        <kendo-grid-column field="ShipAddress" title="Ship Address" [width]="200"></kendo-grid-column>
        <kendo-grid-column field="ShipCity" title="Ship City" [width]="100"></kendo-grid-column>
        <kendo-grid-column field="ShipCountry" title="Ship Country" [width]="100"></kendo-grid-column>
      </kendo-grid>
  `,
  styles: [`
      .k-grid tbody td {
        white-space: nowrap;
        height: 40px;
      }
  `]
})
export class AppComponent {
    public loading: boolean;

    public state: any = {
        skip: 0,
        take: 50
    };

    public query: any;
    private stateChange = new BehaviorSubject<any>(this.state);

    constructor(private service: OrdersService) {

        this.query = this.stateChange.pipe(
            tap(state => {
                this.state = state;
                this.loading = true;
            }),
            switchMap(state => service.fetch(state)),
            tap(() => {
                this.loading = false;
            })
        );
    }

    public pageChange(state: any): void {
        this.stateChange.next(state);
    }
}
